# QRadar

This is terraform for creating a cloudtrail trail that pushes all management events to a cloudwatch log group, and creates an eventbridge rule that pushes guardduty events to a log group.

It also creates the IAM resources to allow the above actions from taking place, as well as an IAM user that can assume the IAM role to be able to read the log groups (from QRadar).


